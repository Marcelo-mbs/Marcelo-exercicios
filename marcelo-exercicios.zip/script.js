function clicar() {
  alert("Funcionou!");
}
